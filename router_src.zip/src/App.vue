<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router';
import AppR_01 from './components/AppRouter_01.vue'

</script>

<template>
  <h1>router </h1>
  <AppR_01 />
  <nav>
    <RouterLink to="/">主页</RouterLink>
    <RouterLink to="/about">关于</RouterLink>
    <RouterLink :to="{ name: 'd1Params' }">d1 看看 Params</RouterLink>
    <RouterLink :to="{ name: 'd1Query' }">d1 看看 Query</RouterLink>
    <RouterLink :to="{ name: 'd1Props' }">d1 看看 Props 解耦</RouterLink>

    <RouterLink to="/goods">去商城看看</RouterLink>
    <!-- 方式 1：直接拼接路径 -->
    <RouterLink to="/user/123">查看用户 123</RouterLink>
    <!-- 方式 2：使用命名路由 + params 属性（推荐） -->
    <!-- <RouterLink :to="{ name: 'userDetail', params: { id: '123' } }">查看用户123</RouterLink> -->
    <RouterLink :to="{
      name: 'userDetail',
      params: {
        id: '八九十'
      }
    }">查看用户 123八九十</RouterLink>
  </nav>
  <nav>
    <h3>重定向和别名</h3>
    <RouterLink to="/redirectGo2">重定向 to="/redirectGo2", 点击重定向到主页/</RouterLink>
    <RouterLink to="/search/123">动态路由重定向 to="/search/123", path:'/search/:keyword',</RouterLink><br/>
    <RouterLink to="/zhuye">主页 / 的别名：to="zhuye"</RouterLink>
    <RouterLink to="/home">主页 / 的别名：to="home"</RouterLink>
  </nav>
  <nav>
    <h2>路由守卫相关 登录</h2>
    <router-link to="/login">登录</router-link>
    <router-link to="/dashboard">去控制台</router-link>
    <router-link to="/vip"> to vip</router-link>
    <router-link to="/meta_01">to /meta_01</router-link>
  </nav>
  <nav>
    <h2>路由导航守卫 Navigation Guards</h2>
  </nav>


  <hr />
  <div>
    <RouterView />
  </div>
</template>

<style scoped>
nav a {
  margin: 5px 10px;
}
</style>
