import { createRouter, createWebHistory } from 'vue-router'

// 导入
import Home from '../views/HomeV.vue'
import About from '../views/ViewsAbout.vue'
// 下面的 ex1 以路由懒加载模式导入组件，不需要在顶部 import
// import About_Ex1 from '../pages/ViewsAboutEx1.vue'
// 404
// import NotFound from '@/views/NotFound.vue'

// 1. 导入商品路由模块 goods
import goodsRoutes from '@/router/modules/goods'

// 导入 user 路由模块
import userRoutes from '@/router/modules/user.ts'

// d1、导入 Params_Router 模块
import ParamsRoutes from '@/router/modules/d1_Params_Router.ts'
import QueryRouter from '@/router/modules/d1_Query_Router.ts'
import PropsRouter from '@/router/modules/d1_Props_Router.ts'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    // d1、导入 ParamsRouter.ts 路由规则 展开
    ...ParamsRoutes,

    // d1、导入 QueryRouter.ts 路由规则 展开
    ...QueryRouter,

    // d1、导入 PropsRouter.ts 路由规则，解耦模块展示
    ...PropsRouter,

    {
      path: '/about',
      name: 'about',
      component: About,
      children: [
        {
          // 注意：子路由的 path 如果不加斜杠 '/'，会自动拼接在父路径后面，即 '/a2/ex1'
          path: 'ex1',
          name: 'ex1Page',
          // component: About_Ex1,
          // 路由懒加载
          // 不需要提前 import，也不需要起变量名，直接写文件路径即可
          // component: () => import('../pages/ViewsAboutEx1.vue'),
          component: () => import('@/pages/ViewsAboutEx1.vue'),
          children: [
            {
              path: 'ex1m1',
              name: 'ex1m1Page',
              component: () => import('../pages/ViewsAboutEx1m1.vue')
            },
            {
              path: 'ex1m2',
              name: 'ex1m2Page',
              component: () => import('../pages/ViewsAboutEx1m2.vue')
            }
          ]
        }
      ]
    },

    // 2、导入 goods 路由规则数组
    // 使用 ... 展开数组
    ...goodsRoutes,    // 展开注入 /goods 和 /goods/:id

    // 导入 user 路由规则
    ...userRoutes,

    /*
    ** 【重定向与别名】
    ** 1、redirect：强行转场，url 会变。
    ** 2、alias：url 不变，组件换掉。
    */
    // 【重定向与别名 1】重定向 redirect
    // 字符串重定向、对象重定向、函数式动态重定向。
    // 访问 to="/redirectGo2", 但是重定向到 主页/
    {
      path: '/redirectGo2',
      redirect: '/',  // 1. 基础重定向（直接写字符串路径）
      // 2. 重定向到命名路由
      // redirect: { name: 'home' },
      // 3. 动态重定向（根据参数决定去哪）↓↓↓↓↓
    },
    {
      path: '/search/:keyword',
      // 3. 动态重定向（根据参数决定去哪）
      redirect: to => {
        // to 是目标对象，可以拿到 params 里的参数
        // 这个query:{id:xxx} 是自定义键值对 例如YourName:'xxx'
        return { path: `/d1_Query_Views`, query: { id: to.params.keyword } }
      }
    },
    //【重定向与别名 2】别名 alias 
    // 允许同一个组件通过不同的 URL 路径访问。
    {
      path: '/',
      component: Home,
      // 允许通过 '/' 或 '/home' 或 '/zhuye' 访问，且地址栏不会发生重定向跳转
      alias: ['/home', '/zhuye', '/index']
    },


    // 【路由守卫】
    // 【路由守卫】
    // 【1】全局守卫：对项目中所有路由跳转都生效。
    // 【2】路由独享守卫：只对某一个特定路由生效。
    // 【3】组件内守卫：定义在 Vue 组件内部，只针对该组件生效。
    // 1. 最常用的“全局前置守卫”（全站通用关卡）
    {
      path: '/login',
      component: () => import('@/views/Login.vue'),
    },
    {
      path: '/dashboard',
      component: () => import('@/views/LoginDashboard.vue'),
      meta: { requiresAuth: true } // 标记：该页面需要登录
    },
    // 2. 路由独享守卫：只对某一个特定路由生效。
    {
      path: '/vip',
      component: () => import('@/views/VipViews.vue'),
      // 【2.1】 路由独享守卫：只有进这个页面前才会触发
      beforeEnter: (to, from) => {
        // const isVip = false // 假设从某处拿到 VIP 状态
        // 1. 从 localStorage 里读取刚才 LoginVip 存进去的值
        const vipToken = localStorage.getItem('vip')

        // 2. 判断是否是 vip999
        const isVip = vipToken === 'vip999'

        // 3. 如果不是 VIP，拦截并提示，重定向回登录页或首页
        if (!isVip) {
          alert('只有 VIP 才能进入该页面！')
          return '/'  // 拦截并重定向
        }
        // 4. 如果是 VIP，不需要写 return，或者 return true，就会顺利进入 /vip 页面

      }
    },
    /* 
    *  路由元信息（meta）
    *  核心概念：meta 是一个“附加信息仓库”，
    *           可以在定义路由时，给每个路由贴上各种自定义的标签（元数据）。
    *  经典场景：配合全局守卫做权限校验（“这个页面需要登录吗？”）或者动态修改网页标题。
    *  
    */
    {
      path: '/meta_01',
      component: () => import('@/views/d1_meta_01.vue'),
      // 通过 meta 携带自定义标签
      meta: {
        // requiresAuth: true,   // 标记：该页面需要登录才能看
        title: 'meta测试页面用',// 标记：页面的中文标题
        vipNumber: 999,       // 标记：本页面的 vip 要求的级别数字
        roles: ['admin'],     // 标记：允许访问的角色
      }
    },



    // ... 其他正常页面

    // 404 NotFound模块 必须放在最底部！！
    {
      path: '/:pathMatch(.*)*',
      name: 'NotFound',
      // component: () => import('../views/NotFound.vue'),
      component: () => import('@/views/NotFound.vue'),
    }
  ],
})


//
//
// 【路由守卫】
// 【1】全局守卫：对项目中所有路由跳转都生效。
//               router.beforeEach（全局前置守卫：最常用的登录拦截）
//               router.beforeResolve（全局解析守卫）
//               router.afterEach（全局后置钩子：改标题、关进度条）
// 【2】路由独享守卫：只对某一个特定路由生效。
//                  beforeEnter（路由独享守卫：写在单个路由规则里的专属检查） 
// 【3】组件内守卫：定义在 Vue 组件内部，只针对该组件生效
//                beforeRouteEnter（在渲染该组件的路由被确认前调用）
//                beforeRouteUpdate（当路由发生变化，但组件被复用时调用）
//                beforeRouteLeave（当导航离开该组件的对应路由时调用）
//
// 
// 【1.1】 全局前置守卫 router.beforeEach：跳转前触发
//  时机：在任何路由跳转开始之前触发。
//  用途：最常用，做登录拦截、权限校验。
router.beforeEach((to, from) => {
  // to: 即将要进入的路由对象 / 即将要进入的目标
  // from: 当前正要离开的路由对象 / 当前导航正要离开的路由

  /* 
  // 当这两个条件同时满足（&&）时。
  // 说明“一个没登录的用户，正试图闯入需要权限的内部页面”。
  if (
    // 检查用户是否已登录；如果登录了就为false，没登录就为true真；
    !isAuthenticated &&
    // 避免无限重定向；要to去的地方不是 login 页面；目标页面不是登录页。
    to.name !== 'Login'
  ) {
    // 将用户重定向到登录页面
    return { name: 'Login' }
  } })
  */

  // 假设从 localStorage 判断登录状态
  // const isAuthenticated = Boolean(localStorage.getItem('token')) // 假设从 localStorage 判断登录状态

  // 假设，从 localStorage 中获取 name ，判断登录信息
  const isAuthenticated = Boolean(localStorage.getItem('name'))
  // const isAuthenticated = Boolean(localStorage.getItem('name') === '111')

  // 1. 未登录，试图访问需要权限的页面 -> 拦截到登录页
  // 如果页面需要登录，但用户未登录 -> 重定向到登录页
  // // 只有当目标页面明确需要登录，且用户确实未登录时，才拦截去 /login
  if (to.meta.requiresAuth && !isAuthenticated) {
    return { path: '/login' } // 返回目标路径直接触发重定向
  }

  // 2. 已登录，试图访问登录页 -> 自动送到后台
  if (to.path === '/login' && isAuthenticated) {
    alert('您已经登录了，如需登录其他账号，请先退出登录!')
    return { path: '/dashboard' }
  }

  // // 允许正常通行
  // 返回 true 或不返回，表示允许正常跳转

  ////////////////////
  //  meta 测试代码块区域，第 150 行
  // 1. 读取 meta 里的网页标题并修改
  if (to.meta.title) {
    document.title = to.meta.title as string
  }
})
// end: beforeEach

// 【1.2】全局解析守卫 router.beforeResolve
//  时机：在 beforeEach 之后、组件内守卫和异步路由组件被解析之后触发。
//  用途：确保所有异步组件都加载完了，适合做一些数据预加载或收尾检查。
router.beforeResolve((to, from) => {
  console.log('所有异步组件和组件守卫准备就绪，即将进入页面')
})

// 【1.3】全局后置钩子 router.afterEach
//  时机：在路由跳转完全结束、页面渲染完成后触发。
//  注意：没有返回值，无法中断或改变导航。
//  用途：修改网页标题（document.title）、关闭加载进度条、页面埋点统计。
router.afterEach((to, from) => {
  document.title = (to.meta.title as string) || '默认标题'
})

// 【2.1】路由独享守卫 beforeEnter
// 写在哪：直接写在 routes 路由规则数组里，只对当前这一个路由生效。
// 时机：访问该特定路由时触发。
// 用途：针对某个单独的页面（如后台管理页）做专属的权限拦截。
// 使用在本代码页的第 99 行

/*
*  【3】 Vue组件内的守卫
* 【3.1】 beforeRouteEnter
* 时机：在渲染该组件的路由被确认前调用。
* 注意：此时组件实例还没被创建，无法在代码里使用 this。
*   // Options API 写法
  export default {
    beforeRouteEnter(to, from) {
      console.log('准备进入这个组件，此时拿不到 this')
    }
  }
*
* 【3.2】 beforeRouteUpdate
* 时机：当路由发生变化，但组件被复用时调用（例如从 /user/1 跳转到 /user/2）。 
* 用途：可以在这里根据新的参数重新请求数据。
* export default {
    beforeRouteUpdate(to, from) {
      // id 变了，重新获取新用户的数据
      this.fetchData(to.params.id) 
    } 
  }
*
* 【3.3】 beforeRouteLeave
* 时机：当导航离开该组件的对应路由时调用。
* 用途：防止用户表单没保存就误触离开，弹窗提示。
  export default {
    beforeRouteLeave(to, from) {
      const answer = window.confirm('修改的内容尚未保存，确定要离开吗？')
      if (!answer) return false // 返回 false 可以取消导航，留在当前页
    }
  }
*/



export default router
